﻿namespace Sudoku1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.easy_panel = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.play_panel = new System.Windows.Forms.Panel();
            this.stas_btn = new System.Windows.Forms.Button();
            this.play_btn = new System.Windows.Forms.Button();
            this.mode_panel = new System.Windows.Forms.Panel();
            this.hard_rdbtn = new System.Windows.Forms.RadioButton();
            this.medium_rdbtn = new System.Windows.Forms.RadioButton();
            this.easy_rdbtn = new System.Windows.Forms.RadioButton();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.medium_panel = new System.Windows.Forms.Panel();
            this.hard_panel = new System.Windows.Forms.Panel();
            this.easy_panel.SuspendLayout();
            this.play_panel.SuspendLayout();
            this.mode_panel.SuspendLayout();
            this.medium_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // easy_panel
            // 
            this.easy_panel.BackColor = System.Drawing.Color.Transparent;
            this.easy_panel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("easy_panel.BackgroundImage")));
            this.easy_panel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.easy_panel.Controls.Add(this.panel3);
            this.easy_panel.Location = new System.Drawing.Point(447, 152);
            this.easy_panel.Name = "easy_panel";
            this.easy_panel.Size = new System.Drawing.Size(340, 453);
            this.easy_panel.TabIndex = 0;
            this.easy_panel.Visible = false;
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(448, 154);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(337, 441);
            this.panel3.TabIndex = 1;
            // 
            // play_panel
            // 
            this.play_panel.BackColor = System.Drawing.Color.Transparent;
            this.play_panel.Controls.Add(this.mode_panel);
            this.play_panel.Controls.Add(this.stas_btn);
            this.play_panel.Controls.Add(this.play_btn);
            this.play_panel.Location = new System.Drawing.Point(66, 152);
            this.play_panel.Name = "play_panel";
            this.play_panel.Size = new System.Drawing.Size(336, 453);
            this.play_panel.TabIndex = 0;
            // 
            // stas_btn
            // 
            this.stas_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.stas_btn.Location = new System.Drawing.Point(65, 335);
            this.stas_btn.Name = "stas_btn";
            this.stas_btn.Size = new System.Drawing.Size(211, 51);
            this.stas_btn.TabIndex = 4;
            this.stas_btn.Text = " ";
            this.stas_btn.UseVisualStyleBackColor = true;
            // 
            // play_btn
            // 
            this.play_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.play_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.play_btn.Location = new System.Drawing.Point(40, 251);
            this.play_btn.Name = "play_btn";
            this.play_btn.Size = new System.Drawing.Size(261, 59);
            this.play_btn.TabIndex = 3;
            this.play_btn.Text = " ";
            this.play_btn.UseVisualStyleBackColor = true;
            this.play_btn.Click += new System.EventHandler(this.play_btn_Click);
            // 
            // mode_panel
            // 
            this.mode_panel.BackColor = System.Drawing.Color.White;
            this.mode_panel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.mode_panel.Controls.Add(this.hard_rdbtn);
            this.mode_panel.Controls.Add(this.medium_rdbtn);
            this.mode_panel.Controls.Add(this.easy_rdbtn);
            this.mode_panel.Controls.Add(this.textBox1);
            this.mode_panel.Controls.Add(this.label2);
            this.mode_panel.Controls.Add(this.label1);
            this.mode_panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mode_panel.Location = new System.Drawing.Point(0, 0);
            this.mode_panel.Name = "mode_panel";
            this.mode_panel.Size = new System.Drawing.Size(336, 453);
            this.mode_panel.TabIndex = 2;
            this.mode_panel.Visible = false;
            this.mode_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.mode_panel_Paint);
            // 
            // hard_rdbtn
            // 
            this.hard_rdbtn.AutoSize = true;
            this.hard_rdbtn.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hard_rdbtn.ForeColor = System.Drawing.Color.RoyalBlue;
            this.hard_rdbtn.Location = new System.Drawing.Point(88, 318);
            this.hard_rdbtn.Name = "hard_rdbtn";
            this.hard_rdbtn.Size = new System.Drawing.Size(78, 23);
            this.hard_rdbtn.TabIndex = 5;
            this.hard_rdbtn.TabStop = true;
            this.hard_rdbtn.Text = "HARD";
            this.hard_rdbtn.UseVisualStyleBackColor = true;
            this.hard_rdbtn.CheckedChanged += new System.EventHandler(this.hard_rdbtn_CheckedChanged_1);
            // 
            // medium_rdbtn
            // 
            this.medium_rdbtn.AutoSize = true;
            this.medium_rdbtn.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.medium_rdbtn.ForeColor = System.Drawing.Color.RoyalBlue;
            this.medium_rdbtn.Location = new System.Drawing.Point(88, 278);
            this.medium_rdbtn.Name = "medium_rdbtn";
            this.medium_rdbtn.Size = new System.Drawing.Size(103, 23);
            this.medium_rdbtn.TabIndex = 4;
            this.medium_rdbtn.TabStop = true;
            this.medium_rdbtn.Text = "MEDIUM";
            this.medium_rdbtn.UseVisualStyleBackColor = true;
            this.medium_rdbtn.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // easy_rdbtn
            // 
            this.easy_rdbtn.AutoSize = true;
            this.easy_rdbtn.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.easy_rdbtn.ForeColor = System.Drawing.Color.RoyalBlue;
            this.easy_rdbtn.Location = new System.Drawing.Point(94, 233);
            this.easy_rdbtn.Name = "easy_rdbtn";
            this.easy_rdbtn.Size = new System.Drawing.Size(72, 23);
            this.easy_rdbtn.TabIndex = 3;
            this.easy_rdbtn.TabStop = true;
            this.easy_rdbtn.Text = "EASY";
            this.easy_rdbtn.UseVisualStyleBackColor = true;
            this.easy_rdbtn.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(88, 115);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(178, 22);
            this.textBox1.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Showcard Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label2.Location = new System.Drawing.Point(83, 182);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(178, 30);
            this.label2.TabIndex = 1;
            this.label2.Text = "Select Mode";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label1.Location = new System.Drawing.Point(83, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(183, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "Player Name";
            // 
            // medium_panel
            // 
            this.medium_panel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("medium_panel.BackgroundImage")));
            this.medium_panel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.medium_panel.Controls.Add(this.hard_panel);
            this.medium_panel.Location = new System.Drawing.Point(447, 152);
            this.medium_panel.Name = "medium_panel";
            this.medium_panel.Size = new System.Drawing.Size(340, 447);
            this.medium_panel.TabIndex = 2;
            this.medium_panel.Visible = false;
            // 
            // hard_panel
            // 
            this.hard_panel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("hard_panel.BackgroundImage")));
            this.hard_panel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hard_panel.Location = new System.Drawing.Point(0, 0);
            this.hard_panel.Name = "hard_panel";
            this.hard_panel.Size = new System.Drawing.Size(337, 444);
            this.hard_panel.TabIndex = 0;
            this.hard_panel.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(847, 602);
            this.Controls.Add(this.medium_panel);
            this.Controls.Add(this.easy_panel);
            this.Controls.Add(this.play_panel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.easy_panel.ResumeLayout(false);
            this.play_panel.ResumeLayout(false);
            this.mode_panel.ResumeLayout(false);
            this.mode_panel.PerformLayout();
            this.medium_panel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel easy_panel;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel play_panel;
        private System.Windows.Forms.Button stas_btn;
        private System.Windows.Forms.Button play_btn;
        private System.Windows.Forms.Panel mode_panel;
        private System.Windows.Forms.RadioButton medium_rdbtn;
        private System.Windows.Forms.RadioButton easy_rdbtn;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel medium_panel;
        private System.Windows.Forms.RadioButton hard_rdbtn;
        private System.Windows.Forms.Panel hard_panel;


    }
}

