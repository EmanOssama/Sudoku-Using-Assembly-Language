﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sudoku1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void play_btn_Click(object sender, EventArgs e)
        {
            mode_panel.Visible = true;
            //play_panel.Visible = false;
            play_btn.Visible = false;
            stas_btn.Visible = false;
        }

        private void mode_panel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            easy_panel.Visible = true;
            medium_panel.Visible = false;
            hard_panel.Visible = false;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            easy_panel.Visible = false;
            medium_panel.Visible = true;
            hard_panel.Visible = false;
        }

        private void hard_rdbtn_CheckedChanged_1(object sender, EventArgs e)
        {
            hard_panel.Visible = true;
            //easy_panel.Visible = false;
            //medium_panel.Visible = false;
        }
    }
}
